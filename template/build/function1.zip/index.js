const { Authenticator } = require('cognito-at-edge');
const authenticator = new Authenticator({
  region: 'eu-west-2', 
  userPoolId: 'eu-west-2_MmVonsBv7',
  userPoolAppId: '5lhba59krtb0ttjpcleuhd0cde', 
  userPoolDomain: 'airview_test.auth.eu-west-2.amazoncognito.com' 
});
exports.handler = async (request) => authenticator.handle(request);