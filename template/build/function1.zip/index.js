const { Authenticator } = require('cognito-at-edge');
const authenticator = new Authenticator({
  region: 'eu-west-2', 
  userPoolId: 'us-east-1_YOVDGoL6q',
  userPoolAppId: '51aie3etv7j1913lf2s4v7v91j', 
  userPoolDomain: 'airviewtest.auth.us-east-1.amazoncognito.com' 
});
exports.handler = async (request) => authenticator.handle(request);